<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once "../class" . DIRECTORY_SEPARATOR . "autoloader.php";

session_start();

use Marmi\Template;

ob_start();

echo "SELECT * FROM TABLE WHERE ddd LIKE 'coo%'";

$recette = new \Marmi\Recette("Cookies", "../IMG/cookies.jpeg", "Cookies au pépites de chocolat :D");
$Chocolat = new \Marmi\Ingredient("Chocolat", "");
$Farine = new \Marmi\Ingredient("Farine","");
$Sucre = new \Marmi\Ingredient("Sucre", "");
$ingredients = [$Chocolat, $Farine, $Sucre];
$recette->addIngredients($ingredients);
$recette->render();


$content = ob_get_clean();

Template::render($content);