<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "..".DIRECTORY_SEPARATOR."class".DIRECTORY_SEPARATOR."autoloader.php";

session_start();

$Recherche = new \Marmi\Recherche();

ob_start();

if(isset($_POST["search"])){
    $tab = $Recherche->get(trim($_POST["search"]));
    echo $_POST["search"];
}

if (!isset($tab)):
    echo "Pas de recettes trouvées...";
else :
    $Recherche->render($tab);
endif;


$content = ob_get_clean();

Marmi\Template::render($content);