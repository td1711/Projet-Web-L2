<footer>
    Ceci est un footer.
</footer>
