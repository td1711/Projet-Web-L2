<?php

namespace Marmi;

class Recette{
    private String $titre;
    private array $Ingredients;
    private String $description;
    private String $photo;
    private array $tags;

    function __construct(String $titre, String $photo, String $description){
        $this->titre = $titre;
        $this->Ingredients = array();
        $this->tags = array();
        $this->photo = $photo;
        $this->description = $description;
    }

    function addIngredients(array $nouveaux){
        foreach($nouveaux as $nv){
            if(!in_array($nv,$this->Ingredients)){
                $this->Ingredients[] = $nv;
            }
        }
    }

    function render(){
        ?>
        <div class="recette">
            <img src="<?php echo $this->photo?>">
            <div class="informations">
                <h2 class="titre">
                    <?php echo $this->titre?>
                </h2><?php /*
                <div class="ingredients">
                    <?php
                    foreach($this->Ingredients as $ing) {
                        ?>
                        <div class="ing">
                            <?php $ing->printNom()?>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <div class="description">
                    <?php echo $this->description?>
                </div>*/?>
            </div>
        </div>
        <?php
    }
}