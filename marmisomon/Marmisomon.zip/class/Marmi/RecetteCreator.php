<?php

namespace Marmi;

class RecetteCreator{
    function generateForm():void{?>
        <h1 id="nvxrecette">Nouvelle Recette</h1>
        <form class = create>
            <div class="input-group">
                <label class="label" for="name">
                    Titre
                </label>
                <input id="name" class="form-control" type="text" name="name">
            </div>

            <div class="input-group">
                <label class="label" for="image">
                    Image
                </label>
                <input id="image" class="form-control" type="file" name="image" accept="image/png, image/gif, image/jpeg">
            </div>

            <div class="input-group">
                <label class="label" for="description">
                    Description
                </label>
                <textarea id="description" class="form-control" name="description"></textarea>
            </div>

            <div id="boutons">
                <button class="btn neon" type="submit">Submit</button>
                <button class="btn neon" type="reset">Reset</button>
            </div>
        </form>
        <?php
    }

    function create(){

    }
}