<?php

namespace Marmi;

use PDO;

class MarmiDB{ // Classe DB du TP6
    private PDO $pdo;
    function __construct(){
        $db_name = "tdarques" ; // Nom de la base de données (pré-existante)
        $db_host = "192.168.22.48" ; // Si le serveur MySQL est sur la machine locale
        $db_port = "3306" ; // Port par défaut de MySQL

        // Informations d'authentification de votre script PHP
        $db_user = "tdarques" ; // Utilisateur par défaut de MySQL (... à changer)
        $db_pwd = "17112003" ;  // Mot de passe par défaut pour l'utilisateur root (.. à changer !!!)

        // Connexion à la BDD
        try{
            // Agrégation des informations de connexion dans une chaine DSN (Data Source Name)
            $dsn = 'mysql:dbname=' . $db_name . ';host='. $db_host. ';port=' . $db_port;

            // Connexion et récupération de l'objet connecté
            $this->pdo = new PDO($dsn, $db_user, $db_pwd);
        }

            // Récupération d'une éventuelle erreur
        catch (\Exception $ex){?>
            // Arrêt de l'exécution du script PHP
            <div style="color: red">
            <b>!!! ERREUR DE CONNEXION !!!</b><br>
            Code : <?= $ex->getCode() ?><br>
            Message : <?= $ex->getMessage() ?>
            </div><?php
            // Arrêt de l'exécution du script PHP
            die("-> Exécution stoppée <-") ;
        }

    }

    function getAllGames():void{
        $sql = "SELECT * FROM games ORDER BY name" ;
        $statement = $this->pdo->prepare($sql) ;
        $statement->execute() or die(var_dump($statement->errorInfo())) ;
        $results = $statement->fetchAll(PDO::FETCH_CLASS, "\gdb\GamesRenderer") ; ?>
        <h1>GAMES</h1>
        <div class="games-list">
            <!--Affichage du champ 'name' des objets récupérés -->
            <?php foreach ($results as $game){
                echo $game->getHTML();
            }?>
        </div>
        <?php
    }
}