<?php

namespace Marmi;

class Ingredient{
    private String $nom;
    private String $image;

    function __construct(String $nom, String $image){
        $this->nom = $nom;
        $this->image = $image;
    }

    function printNom(){
        echo $this->nom;
    }
}