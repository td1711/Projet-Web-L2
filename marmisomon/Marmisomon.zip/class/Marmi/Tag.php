<?php

namespace Marmi;

class Tag{
    private String $nom;
}